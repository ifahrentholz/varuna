<?php
  $files = array();
  echo '<h1>EMA Intranet and Extranet Overview</h1>';
  echo '<ul>';
  foreach (glob("*.html") as $file) {
    $files[] = $file;
    echo '<li style="margin:5px 0;"><a href="'.$file.'">'.$file.'</a></li>';
  }
  echo '</ul>';
?>