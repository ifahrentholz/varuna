var EMA = window.EMA || {};

EMA.application = document.querySelector("meta[data-application]").getAttribute("data-application");

$(document).ready(function() {
  
  // Render Views
  EMA.renderLayout();
  EMA.renderViews();
  EMA.initSkipLinks();
  
  // Load Functions on Ajax success
  $('body').on('Loaded', function(){
    EMA.initSingleSlider();
    twttr.widgets.load();
  });
  
});
