/************************************************************************
// INIT single Show Slider
************************************************************************/
var EMA = window.EMA || {};

EMA.initSingleSlider = function() {
  if ($('.single-slider').length > 0) {

    $('.single-slider').slick({
      infinite: false,
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: true,
      arrows: false
    });
  }
};