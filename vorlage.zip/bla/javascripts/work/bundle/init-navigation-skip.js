/************************************************************************
// INIT skipLinks
************************************************************************/
var EMA = window.EMA || {};

EMA.initSkipLinks = function() {  
  $("a[href^='#']").click(function() {
    $("#"+$(this).attr("href").slice(1)+"")
      .focus()
  });
};