/************************************************************************
// INIT renderLayout
************************************************************************/
var EMA = window.EMA || {};

EMA.renderLayout = function() {
  var naigationskip = 'views/layouts/navigation-skip_'+ EMA.application +'.html';
  var header = 'views/layouts/header_'+ EMA.application +'.html';
  var navigationmain = 'views/layouts/navigation-main_'+ EMA.application +'.html';
  var footer = 'views/layouts/footer_'+ EMA.application +'.html';

  if (naigationskip.length) {
    $('#navigation-skip-wrapper').load(naigationskip);
  }
  if (header.length) {
    $('#header').load(header);
  }
  if (navigationmain.length) {
    $('#navigation-main').load(navigationmain);
  }
  if (footer.length) {
    $('#footer').load(footer);
  }
};
