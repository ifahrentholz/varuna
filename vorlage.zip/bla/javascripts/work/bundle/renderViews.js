/************************************************************************
// INIT renderViews
************************************************************************/
var EMA = window.EMA || {};

EMA.renderViews = function() {
  
  var content = $('#content').data('app-view');
  var marginal = $('#marginal').data('app-view');
  
  if (content) {
    $('#content').load('views/'+ content +'/content_'+ EMA.application +'.html', function() {
      $('body').trigger('Loaded');
    });
  } else {
    //$('#content').load(EMA.view); // render Startsite?
  }
  if (marginal) {
    $('#marginal').load('views/'+ marginal +'/marginal_'+ EMA.application +'.html', function() {
      $('body').trigger('Loaded');
    });
  } else {
    //$('#marginal').load(EMA.marginal); // render Startsite?
  }
  
};
