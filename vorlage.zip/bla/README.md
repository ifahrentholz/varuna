==================================================
1. Ordnerstruktur
==================================================
1.1 
views/
  | layouts/
  |   header.html
  |   footer.html
  | home/
  |   marginal_intra.html
  |   marginal_extra.html
  |   content_intra.html
  |   content_extra.html
  | detail/
  |   marginal_intra.html
  |   marginal_extra.html
  |   content_intra.html
  |   content_extra.html
  | marginal_default
  |   marginal_intra.html
  |   marginal_extra.html
fonts/
css/
  | dist/
  | work/
    | importerIntra.scss
    | importerExtra.scss
    | _importerCommon.scss
    | |
    | utils/
    | | bootstrap/
    | | mixins/
    | | libs/
    | | _fonts
    | intranet/
    | | _components/ (How to siehe: 8.)
          _slider.scss
    | extranet/
    | | _componentExtraA
    | common/
    | | _layout
        _panel.scss
    | | _components/ (How to siehe: 8.)
          _slider.scss
js/
|-- dist/					 
|   |-- main.js		
|-- work/					
    |-- utils/
    |--|-- libs/
             jquery/
             bxslider/bxslider.js
|   |-- bundle/		
    |--   initslider/initslider.js //init function $('slider').bxslider({})
|   |-- main.js


==================================================
2. HOW TO REPONSIVE?
==================================================
.moduleXY {
  width: 800px;
  @include respond-to(xs) {
    width: 100%;
  }
  @include respond-to(md) {
    width: 500px;
  }
}


==================================================
3. HOW TO DRY?
==================================================
- XHR 

SICHT_STARTSEITE.html
<header class="header">
  <nav id="primenav" data-xhr-url="http://nav.html" data-active-link="1"></nav>
</header>
<div class="container" data-xhr-url="startseite-content.html"></div>
<footer id="footer" data-xhr-url="http://filexy.html"></footer>


SICHT_DETAIL.html
<header class="header">
  <nav id="primenav" data-xhr-url="http://nav.html" data-active-link="2"></nav>
</header>
<div class="container" data-xhr-url="detailseite-content.html"></div>
<footer id="footer" data-xhr-url="http://filexy.html"></footer>


==================================================
4. SVN!!! Muss sein!!!
==================================================


==================================================
5. BITV ? HOW TO
==================================================
https://issues.init.de/browse/ZDB-311


==================================================
6. Mediamatcher falls notwendig -> TIM
==================================================


==================================================
7. Gruntfile -> TimÖöö
==================================================
https://github.com/timbuktuuu/init-grunt-sample


==================================================
8. NAMINGCONVENTIONS
==================================================
- english (no denglish)
- commit-messages (bsp: was haste gemacht im präsens -> add details-page + ticketnr)
- includes immer ans ende schreiben
- Bootstrap: http://www.w3schools.com/bootstrap/bootstrap_grid_system.asp
-----
SCSS: 
-----
<div class="c__panel">
	<div class="c__panel-header">
	<div class="c__panel-body">
		class="c__slider"
	<div class="c__panel-footer">

.c__panel {
	c__panel-header { background: $panel-header-bg; @include fs(12px); }
	c__panel-body {}
	c__panel-footer {}
}

vars:
$panel-header-bg: #ff0000;

css/work/common/components/panel.scss
css/work/common/components/slider.scss
css/work/intranet/components/slider.scss || intra-spezifische styles

